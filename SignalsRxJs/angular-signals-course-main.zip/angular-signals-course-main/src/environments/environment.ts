export const environment = {
  apiRoot: ""
};
